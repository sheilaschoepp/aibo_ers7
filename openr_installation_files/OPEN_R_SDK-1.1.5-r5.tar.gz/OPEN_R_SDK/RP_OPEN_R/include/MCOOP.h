//
// MCOOP.h
//  - APIs available on OPEN-R Emulator
//

#include <_mcoop.h>
#include <rmcoop.h>

