//
// ObserverInfo.h
//
// Copyright (C) 2002 Sony Corporation
// All Rights Reserved.
//

//
// class ObserverInfo has changed its name to OObserverInfo.
// Although normal users need not include this file, old file 
// ObserverInfo.h is added for legacy support purpose.
// 

#warning class name ObserverInfo has changed to OObserverInfo.

#include <OPENR/OObserverInfo.h>
