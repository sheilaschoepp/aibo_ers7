//
// OObserverVector.h
//
// Copyright (C) 2001 Sony Corporation
// All Rights Reserved.
//

#ifndef _OObserverVector_h_DEFINED
#define _OObserverVector_h_DEFINED

#include <OPENR/OObserver.h>

typedef OObserver OObserverVector;

#endif // _OObserverVector_h_DEFINED
