/*
 *  Copyright 2002 Sony Corporation
 */
#ifndef _antSharedBuffer_H_
#define _antSharedBuffer_H_

#include <antTypes.h>

#include <antSharedBufferDef.h>

#ifdef ANT_INLINE
#include <antSharedBufferFunc.h>
#endif

#endif

